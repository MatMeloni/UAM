/**
 *
 * @author Kakugawa
 */
public class NumeroMaximoJogadorExcecao extends Exception{

    public String getMessage(){
        return "Numero maximo de jogadores atingido.";
    }
}
