
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Kakugawa
 */
public class Tabuleiro {

    private boolean casasTabuleiro[];
    private ArrayList<Jogador> listaJogadores;

    public Tabuleiro() {
        this.listaJogadores = new ArrayList<>();
        iniciarTabuleiro(10);
    }

    public Tabuleiro(int tamanho) {
        this.listaJogadores = new ArrayList<>();
        iniciarTabuleiro(tamanho);
    }

    public void iniciarTabuleiro(int tamanho) {
        if (tamanho < 10) {
            this.casasTabuleiro = new boolean[10];
        } else {
            this.casasTabuleiro = new boolean[tamanho];
        }
        for (int i = 0; i < this.casasTabuleiro.length; i++) {
            this.casasTabuleiro[i] = false;
        }
    }

    public void printCasaTabuleiro() {
        System.out.println("===========================================");
        System.out.println("=================TABULEIRO=================");
        System.out.println("===========================================");

        for (int i = 0; i < this.casasTabuleiro.length; i++) {

            if (this.casasTabuleiro[i] == true) {
                System.out.println("| "+ (i+1) +" | " + verificaJogadoresNaCasa(i));
            } else {
                System.out.println("| " + (i + 1) + " | ");
            }

        }

    }

    public void inserirJogador() throws NumeroMaximoJogadorExcecao {

        if (this.listaJogadores.size() < 4) {
            // Cadastrar jogador
            Scanner entrada = new Scanner(System.in);
            System.out.println("Digite o nome: ");
            String nome = entrada.nextLine();

            int tipoPeao = 0;
            do {

                System.out.println("Digite o tipo de peao: 1- Par ou 2- Impar");
                tipoPeao = entrada.nextInt();
                if (tipoPeao != 1 && tipoPeao != 2) {
                    System.err.println("Opcao Invalida");
                }

            } while (tipoPeao != 1 && tipoPeao != 2);

            Jogador novoJogador;

            switch (tipoPeao) {
                case 1:
                    PeaoPar pPar = new PeaoPar();
                    novoJogador = new Jogador(nome, pPar);
                    this.listaJogadores.add(novoJogador);
                    break;
                case 2:
                    PeaoImpar pImpar = new PeaoImpar();
                    novoJogador = new Jogador(nome, pImpar);
                    this.listaJogadores.add(novoJogador);
                    break;
            }

        } else {
            throw new NumeroMaximoJogadorExcecao();
        }

    }
    
    public void listarJogadores(){
        
        System.out.println("==============================================");
        System.out.println("================LISTA JOGADORES===============");
        System.out.println("==============================================");
        
        if (this.listaJogadores.isEmpty()){
            System.err.println("Nao existe jogadores no tabuleiro.");
        } else {
            for (int i = 0 ; i < this.listaJogadores.size() ; i++){
                System.out.println("JOGADOR NRO " + (i + 1));
                this.listaJogadores.get(i).imprimirJogador();
            }
        }
        
    }
    
    public void alterarTamanhoTabuleiro(){
        
        Scanner entrada = new Scanner(System.in);
        System.out.println("Digite o novo tamanho: ");
        int tamanho = entrada.nextInt();
        iniciarTabuleiro(tamanho);
        
    }
    
    private boolean possuiVencedor(){
        if (this.casasTabuleiro[casasTabuleiro.length - 1] == true){
            System.out.println("Temos um vencedor... " + verificaJogadoresNaCasa(casasTabuleiro.length - 1));
            return true;
        }
        return false;
    }
    
    private String verificaJogadoresNaCasa(int numeroCasa){
        
        String nomeJogadores = "";
        
        for(int i = 0; i < this.listaJogadores.size(); i++){
            if (this.listaJogadores.get(i).getPosicaoAtual() == numeroCasa){
                nomeJogadores = nomeJogadores + " " + this.listaJogadores.get(i).getNome();
            }
        }        
        return nomeJogadores;        
    }
    
    public void jogar(){
        
        if(this.listaJogadores.size() >= 2){
            
            int numeroJogadorAtual = 0;
            
            while (possuiVencedor() == false){
                
                if(numeroJogadorAtual == this.listaJogadores.size()){
                    numeroJogadorAtual = 0;
                }
                
                Jogador jogadorAtual = this.listaJogadores.get(numeroJogadorAtual);
                System.out.println("eh a vez do jogador... " + jogadorAtual.getNome());
                System.out.println("Rodando o dado....");
                int numeroDado = Dado.rodarDado();
                
                int posicaoAtual = jogadorAtual.getPosicaoAtual();
                
                int novaPosicao = posicaoAtual + jogadorAtual.getPeaoEscolhido().movimentar(numeroDado);
                
                //Para não estourar o vetor
                if (novaPosicao > this.casasTabuleiro.length - 1){
                    novaPosicao = this.casasTabuleiro.length - 1;
                }
                
                this.casasTabuleiro[novaPosicao] = true;
                jogadorAtual.setPosicaoAtual(novaPosicao);
                
                if(posicaoAtual != -1){
                    if (verificaJogadoresNaCasa(posicaoAtual).equals("")){
                        this.casasTabuleiro[posicaoAtual] = false;
                    }
                }
                
                numeroJogadorAtual++;
                
                printCasaTabuleiro();
                Scanner entrada = new Scanner (System.in);
                System.out.println("Pressione ENTER para continuar");
                entrada.nextLine();
            }
            System.out.println("O JOGO ESTA ENCERRADO!!!");
            System.exit(0);
        } else {
            System.err.println("Nao pode iniciar a partida.");
        }
    }
}
