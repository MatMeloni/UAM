/**
 *
 * @author Kakugawa
 */
public abstract class Peao {
    
    public abstract int movimentar(int numeroDado);
    
}
