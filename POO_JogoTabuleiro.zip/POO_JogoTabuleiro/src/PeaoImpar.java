/**
 *
 * @author Kakugawa
 */
public class PeaoImpar extends Peao{
    
    public int movimentar(int numeroDado){
        
        if (numeroDado % 2 != 0)
            return numeroDado + 1;
        else
            return numeroDado;   
    }
}
