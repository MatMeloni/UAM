/**
 *
 * @author Kakugawa
 */
public class Jogador {

    private String nome;
    private Peao peaoEscolhido;
    private int posicaoAtual;

    public Jogador(String nome, Peao peaoEscolhido) {
        this.nome = nome;
        this.peaoEscolhido = peaoEscolhido;
        //Posicao fora do tabuleiro
        this.posicaoAtual = -1;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Peao getPeaoEscolhido() {
        return peaoEscolhido;
    }

    public void setPeaoEscolhido(Peao peaoEscolhido) {
        this.peaoEscolhido = peaoEscolhido;
    }

    public int getPosicaoAtual() {
        return posicaoAtual;
    }

    public void setPosicaoAtual(int posicaoAtual) {
        this.posicaoAtual = posicaoAtual;
    }  

    public void imprimirJogador() {
        System.out.println("Nome do jogador: " + this.nome);

        if (this.peaoEscolhido instanceof PeaoImpar) {
            System.out.println("Tipo de Peao: Impar");
        } else {
            if (this.peaoEscolhido instanceof PeaoPar) {
                System.out.println("Tipo de Peao: Par");
            }
        }

    }
}
