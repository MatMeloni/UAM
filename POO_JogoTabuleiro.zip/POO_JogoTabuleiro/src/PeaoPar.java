/**
 *
 * @author Kakugawa
 */
public class PeaoPar extends Peao{
    
    public int movimentar (int numeroDado){
        if (numeroDado % 2  == 0)
            return numeroDado + 1;
        else
            return numeroDado;
    }
}
