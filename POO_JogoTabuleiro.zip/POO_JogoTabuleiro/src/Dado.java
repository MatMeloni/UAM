
import java.util.Random;

/**
 *
 * @author Kakugawa
 */
public class Dado {
    public static int rodarDado() {

        Random random = new Random();
        System.out.println("Rodando o dado...");

        int numeroSorteado = 1 + random.nextInt(6); // (0 1 2 3 4 5) + 1

        System.out.println("Numero do dado = " + numeroSorteado);

        return numeroSorteado;
    }
}
