
import java.util.Scanner;

/**
 *
 * @author Kakugawa
 */
public class AppTabuleiro {
    public static void main(String[] args) {

        int opcao = 0;

        Scanner entrada = new Scanner(System.in);

        Tabuleiro tabuleiro = new Tabuleiro();

        do {

            menuPrincipal();
            opcao = entrada.nextInt();

            switch (opcao) {
                case 1:
                    tabuleiro.alterarTamanhoTabuleiro();
                    break;
                case 2:
                    try {
                        tabuleiro.inserirJogador();
                    } catch (NumeroMaximoJogadorExcecao ex) {
                        System.err.println(ex.getMessage());
                    }

                    break;
                case 3:
                    tabuleiro.listarJogadores();
                    break;
                case 4:
                    tabuleiro.jogar();
                    break;
                case 9:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opcao Invalida");
            }

        } while (opcao != 9);

    }

    public static void menuPrincipal() {

        System.out.println("**************************************************");
        System.out.println("*********** JOGO DE TABULEIRO POO ****************");
        System.out.println("**************************************************");

        System.out.println("1 - Alterar tamanho do tabuleiro.");
        System.out.println("2 - Adicionar Jogador");
        System.out.println("3 - Listar Jogadores");
        System.out.println("4 - Iniciar o jogo");
        System.out.println("9 - Sair");

        System.out.print("Digite a opcao desejada ============> ");

    }
}
