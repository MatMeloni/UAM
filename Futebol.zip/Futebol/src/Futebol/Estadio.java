package Futebol;
/*
 *  Marcelo Coelho 32031270
 */
public class Estadio {
    int anoInaug;
    String nome;
    int capacid;
    
    Estadio(int anoI,String Nome,int capacidade){
        this.anoInaug = anoI;
        this.nome = Nome;
        this.capacid = capacidade;
    }
    
    int getAnoInaug(){
       return anoInaug; 
    }
    String getNome(){
       return nome; 
    }
    int getCapacidade(){
       return capacid; 
    }
}
