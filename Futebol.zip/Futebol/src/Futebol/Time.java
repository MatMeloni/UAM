package Futebol;
/*
 *  Marcelo Coelho 32031270
 */
public class Time {
    String nome;
    Estadio[] estadio;
    int qntEstadio;
    
    Time(String Nome){
        this.nome = Nome;
        estadio = new Estadio[2];
    }
    
    void getInfoEstadios(){
        for (int i = 0; i < this.estadio.length; i++) {
            int numero = i+1;
            if(estadio[i]== null)
                break;
            else{
            System.out.println("Nome do estadio "+ numero + ":" + estadio[i].getNome());
            System.out.println("Capacidade do estadio "+ numero + ":" + estadio[i].getCapacidade());
            System.out.println("Ano do estadio "+ numero + ":" + estadio[i].getAnoInaug());
            }
        }
    }
    
    String getNome(){
        return nome;
    }
    
    boolean criaEstadio(int ano,String Nome,int capacidade){
        if(qntEstadio<estadio.length){
            estadio[qntEstadio] = new Estadio(ano,Nome,capacidade);
            
            qntEstadio++;
            return true;
        }
        return false;
        
        }
    
    }


